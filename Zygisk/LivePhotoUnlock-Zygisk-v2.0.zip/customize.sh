#!/system/bin/sh
MODDIR=${0%/*}
ui_print "- LivePhotoUnlock Zygisk 安装中..."
APP_DIR=/data/data/com.tencent.mm/files
mkdir -p "$APP_DIR" 2>/dev/null
cp -f "$MODDIR/lib/arm64-v8a/libpine.so" "$APP_DIR/libpine.so" 2>/dev/null
cp -f "$MODDIR/livephoto_module.dex" "$APP_DIR/livephoto_module.dex" 2>/dev/null
chmod 755 "$APP_DIR/libpine.so" 2>/dev/null
chmod 644 "$APP_DIR/livephoto_module.dex" 2>/dev/null
chown u0_a281:u0_a281 "$APP_DIR/libpine.so" "$APP_DIR/livephoto_module.dex" 2>/dev/null
ui_print "- 部署完成"
